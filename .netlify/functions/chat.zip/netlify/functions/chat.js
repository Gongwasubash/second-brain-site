var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// netlify/functions/gh-helpers.js
var require_gh_helpers = __commonJS({
  "netlify/functions/gh-helpers.js"(exports2, module2) {
    var GH_REPO = "Gongwasubash/ai";
    var GH_API = `https://api.github.com/repos/${GH_REPO}/contents`;
    function ktmDate(d = /* @__PURE__ */ new Date()) {
      return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kathmandu", year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
    }
    function ktmTime(d = /* @__PURE__ */ new Date()) {
      return new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Kathmandu", hour: "2-digit", minute: "2-digit" }).format(d);
    }
    function ghHeaders() {
      return {
        Accept: "application/vnd.github.v3+json",
        Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
        "Content-Type": "application/json",
        "User-Agent": "second-brain-terminal"
      };
    }
    function safePath(p) {
      p = (p || "").trim().replace(/^\/+/, "");
      if (!p || p.includes("..") || p.startsWith(".")) return null;
      if (!p.endsWith(".md")) p += ".md";
      return p;
    }
    async function ghRead(path) {
      const r = await fetch(`${GH_API}/${path}?ref=main`, { headers: ghHeaders() });
      if (r.status === 404) return null;
      if (!r.ok) throw new Error(`GitHub read failed: ${r.status}`);
      const d = await r.json();
      return { sha: d.sha, content: Buffer.from(d.content || "", "base64").toString("utf8") };
    }
    async function ghWrite(path, content, sha, message) {
      const body = { message: message || `terminal: update ${path}`, content: Buffer.from(content, "utf8").toString("base64"), branch: "main" };
      if (sha) body.sha = sha;
      const r = await fetch(`${GH_API}/${path}`, { method: "PUT", headers: ghHeaders(), body: JSON.stringify(body) });
      if (!r.ok) throw new Error(`GitHub write failed: ${r.status} ${(await r.text()).slice(0, 200)}`);
      return r.json();
    }
    async function appendLog(text) {
      const idx = await ghRead("wiki/log.md");
      if (!idx) return;
      const content = idx.content.replace(/\s+$/, "") + `
${text}
`;
      await ghWrite("wiki/log.md", content, idx.sha, "terminal: log entry");
    }
    async function actJournal2(text, summary) {
      const date = ktmDate();
      const path = `journal/${date} Terminal Captures.md`;
      const stamp = `## ${ktmTime()} NPT

${text.trim()}
`;
      const cur = await ghRead(path);
      let content;
      if (cur) {
        content = cur.content.replace(/\s+$/, "") + "\n\n" + stamp;
      } else {
        const slug = text.trim().split(/\s+/).slice(0, 4).join("-").replace(/[^\w\-]/g, "").slice(0, 40) || "capture";
        content = `---
date: ${date}
tags:
  - journal
  - terminal
---

# ${date} ${slug}

${stamp}`;
      }
      await ghWrite(path, content, cur?.sha, `terminal: journal capture ${date}`);
      const title = path.split("/")[1].replace(".md", "");
      const line = `- [[${title}]] \u2014 ${summary || "quick captures from web terminal."}`;
      const idx = await ghRead("journal/index.md");
      if (idx && !idx.content.includes(title)) {
        let nc = idx.content;
        const sec = `## ${date}`;
        nc = nc.includes(sec) ? nc.replace(sec, `${sec}

${line}`) : nc.replace(/\s+$/, "") + `

${sec}

${line}
`;
        await ghWrite("journal/index.md", nc, idx.sha, `terminal: index journal ${date}`);
      } else if (idx && summary && idx.content.includes(`${title}]] \u2014 quick captures from web terminal.`)) {
        const nc = idx.content.replace(`${title}]] \u2014 quick captures from web terminal.`, `${title}]] \u2014 ${summary}`);
        await ghWrite("journal/index.md", nc, idx.sha, `terminal: index journal ${date}`);
      }
      await appendLog(`## [${date}] journal | ${title} \u2014 ${summary || text.trim().split(/\s+/).slice(0, 8).join(" ")}`);
      return `saved \u2192 ${path} + index + log`;
    }
    async function actContact2(name, details, summary) {
      name = (name || "").trim();
      if (!name) throw new Error("contact name missing");
      const path = `crm/${name}.md`;
      const date = ktmDate();
      const cur = await ghRead(path);
      let content;
      if (cur) {
        content = cur.content.replace(/\s+$/, "") + `

## Update ${date}

${(details || "").trim() || "(no details given)"}
`;
      } else {
        content = `# ${name}

- Contact: ${(details || "").trim() || "\u2014"}
- Met: via chat, ${date}
- Notes: ${(details || "").trim() || "\u2014"}
`;
      }
      await ghWrite(path, content, cur?.sha, `terminal: contact ${name}`);
      const idx = await ghRead("crm/index.md");
      if (idx && !idx.content.includes(`[[${name}]]`)) {
        const lines = idx.content.split("\n");
        const entry = `- [[${name}]] \u2014 ${summary || (details || "").trim().slice(0, 80) || "added via chat"}`;
        let pos = lines.findIndex((l) => l.startsWith("- [[") && l.toLowerCase() > entry.toLowerCase());
        if (pos < 0) pos = lines.length;
        lines.splice(pos, 0, entry);
        await ghWrite("crm/index.md", lines.join("\n"), idx.sha, `terminal: index contact ${name}`);
      }
      await appendLog(`## [${date}] crm | ${name} \u2014 ${summary || (details || "").trim().slice(0, 80) || "contact updated"}`);
      return `saved \u2192 ${path} + index + log`;
    }
    async function actAppend(path, text) {
      path = safePath(path);
      if (!path || !text?.trim()) throw new Error("path and text required");
      const cur = await ghRead(path);
      const stamp = `

> terminal ${ktmDate()} ${ktmTime()} NPT

${text.trim()}
`;
      const content = cur ? cur.content.replace(/\s+$/, "") + stamp : `# ${path}
` + stamp;
      await ghWrite(path, content, cur?.sha, `terminal: append ${path}`);
      return `saved \u2192 ${path}`;
    }
    async function actRead(path) {
      path = safePath(path);
      if (!path) throw new Error("path required");
      const cur = await ghRead(path);
      if (!cur) throw new Error(`not found: ${path}`);
      return cur.content.slice(0, 4e3);
    }
    async function actLog(text) {
      await appendLog(`## [${ktmDate()}] terminal | ${text.trim()}`);
      return "logged \u2192 wiki/log.md";
    }
    var CLEAN_MODELS = [
      "ling-3.0-flash-fin-free",
      "mimo-v2.5-free",
      "big-pickle",
      "nemotron-3.5-lightning-free",
      "nemotron-3-ultra-free",
      "muse-spark-1.3-contributor-free"
    ];
    async function cleanNote2(chatFn, key, text, kind = "journal note") {
      const fallback = { clean: (text || "").trim(), summary: "" };
      if (!key || !text?.trim()) return fallback;
      const msgs = [
        { role: "system", content: `Rewrite the ${kind} below in clear, proper English: fix grammar and spelling, keep first person, keep every fact, name and number exactly as given. 1-3 short sentences, plain text, no quotes. Then on its own new last line write SUMMARY: followed by a summary of 12 words or fewer. Reply with ONLY the rewritten note plus the SUMMARY line.` },
        { role: "user", content: text.slice(0, 1e3) }
      ];
      for (const model of CLEAN_MODELS) {
        try {
          const { status, data } = await chatFn(key, model, msgs);
          if (status !== 200) {
            if (status === 401 || status === 403) break;
            continue;
          }
          const raw = (data.choices?.[0]?.message?.content || data.choices?.[0]?.message?.reasoning || "").trim();
          if (!raw) continue;
          const lines = raw.split("\n");
          const si = lines.findIndex((l) => /^summary\s*:/i.test(l.trim()));
          if (si >= 0) {
            return {
              clean: lines.slice(0, si).join("\n").trim() || fallback.clean,
              summary: lines[si].replace(/^summary\s*:/i, "").trim().slice(0, 140)
            };
          }
          return { clean: raw.slice(0, 1500), summary: "" };
        } catch {
        }
      }
      return fallback;
    }
    function parseSavePrefix2(text) {
      if (!text) return null;
      let m = text.match(/^\[SAVE-JOURNAL\]\s*([\s\S]*)/);
      if (m) return { kind: "journal", body: (m[1] || "").trim() };
      m = text.match(/^\[SAVE-CONTACT:\s*([^\]]+)\]\s*([\s\S]*)/);
      if (m) return { kind: "contact", name: (m[1] || "").trim(), body: (m[2] || "").trim() };
      return null;
    }
    module2.exports = { ktmDate, ktmTime, safePath, ghRead, ghWrite, appendLog, actJournal: actJournal2, actContact: actContact2, actAppend, actRead, actLog, parseSavePrefix: parseSavePrefix2, cleanNote: cleanNote2 };
  }
});

// netlify/functions/chat.js
var ZEN_BASE = "https://opencode.ai/zen/v1";
var FREE_MODELS = [
  "ling-3.0-flash-fin-free",
  "mimo-v2.5-free",
  "big-pickle",
  "nemotron-3.5-lightning-free",
  "nemotron-3-ultra-free",
  "muse-spark-1.3-contributor-free"
];
async function liveFreeModels(key) {
  try {
    const r = await fetch(`${ZEN_BASE}/models`, { headers: { Authorization: `Bearer ${key}` } });
    if (!r.ok) return FREE_MODELS;
    const d = await r.json();
    const ids = (d.data || []).map((m) => m.id || m);
    const live = FREE_MODELS.filter((m) => ids.includes(m));
    return live.length ? live : FREE_MODELS;
  } catch {
    return FREE_MODELS;
  }
}
async function zenChat(key, model, messages) {
  const r = await fetch(`${ZEN_BASE}/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({ model, messages, temperature: 0.7, max_tokens: 2048 })
  });
  const data = await r.json().catch(() => ({}));
  return { status: r.status, data };
}
function extractText(data) {
  const msg = data.choices?.[0]?.message;
  if (!msg) return "";
  return msg.content || msg.reasoning || "";
}
var { actJournal, actContact, parseSavePrefix, cleanNote } = require_gh_helpers();
exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  try {
    const { message, history = [], context = "" } = JSON.parse(event.body);
    if (!message) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "No message" }) };
    }
    const systemPrompt = `You are Subash's Second Brain AI assistant. You have access to his entire Obsidian knowledge base.

RULES:
1. Answer ONLY based on the provided context. If the data doesn't contain the answer, say so.
2. Be concise and direct. Use bullet points when helpful.
3. When referencing data, mention the source file name.
4. You can synthesize information across multiple pages.
5. Use markdown formatting for readability.
6. If the user wants to REMEMBER, NOTE, LOG or SAVE something to the journal, start your reply with exactly [SAVE-JOURNAL] on the first line, then the note text.
7. If the user wants to ADD or UPDATE a contact/person, start your reply with exactly [SAVE-CONTACT: Full Name] on the first line, then what is known.
8. Otherwise reply normally with no prefix.
9. TONE: warm and friendly, like a helpful friend chatting \u2014 simple everyday words, no jargon, no lectures, no robotic bullet dumps unless a list truly helps.

You know about Subash's interests: AI automation, content creation, Nepal history (Mahispal dynasty), video production, and building systems.`;
    const messages = [
      { role: "system", content: systemPrompt + "\n\n--- SECOND BRAIN DATA ---\n" + context }
    ];
    for (const h of history.slice(-6)) {
      messages.push({ role: h.role === "user" ? "user" : "assistant", content: h.content });
    }
    messages.push({ role: "user", content: message });
    const ZEN_KEY = process.env.OPENCODE_ZEN_KEY;
    let responseText = "";
    let lastErr = "";
    if (ZEN_KEY) {
      const candidates = await liveFreeModels(ZEN_KEY);
      const tryOne = async (model) => {
        const { status, data } = await zenChat(ZEN_KEY, model, messages);
        if (status === 200) {
          const t = extractText(data);
          if (t) return t;
          throw new Error(`${model}: empty reply`);
        }
        throw new Error(`${model}: ${data?.error?.message || data?.error || status}`);
      };
      try {
        responseText = await Promise.any(candidates.slice(0, 3).map(tryOne));
      } catch (e) {
        lastErr = (e.errors || [e]).map((x) => x.message).join(" | ");
      }
    } else {
      lastErr = "OPENCODE_ZEN_KEY not set";
    }
    if (!responseText) {
      try {
        const MISTRAL_KEY = process.env.MISTRAL_API_KEY;
        if (!MISTRAL_KEY) throw new Error("no mistral key");
        const res = await fetch("https://api.mistral.ai/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${MISTRAL_KEY}` },
          body: JSON.stringify({ model: "open-mistral-7b", messages, temperature: 0.7, max_tokens: 2048 })
        });
        const mdata = await res.json();
        if (mdata.error) throw new Error(mdata.error.message || JSON.stringify(mdata.error));
        responseText = mdata.choices?.[0]?.message?.content || "";
      } catch (e) {
        lastErr += ` | mistral: ${e.message}`;
      }
    }
    if (!responseText) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ response: `AI busy right now (${lastErr}). Try again in a minute.`, sources: [] })
      };
    }
    const isSaveReq = /remember|note (it |that |down|to self)|jot (it |that |down)|log (it |that |this)|save (it |that |this|to my)|add (a |new )?contact|new contact|met .*today|phone number/i.test(message);
    const save = parseSavePrefix(responseText);
    if (save && process.env.GITHUB_TOKEN && isSaveReq) {
      try {
        let info;
        if (save.kind === "journal") {
          const cn = await cleanNote(zenChat, ZEN_KEY, save.body, "journal note");
          info = await actJournal(cn.clean, cn.summary);
          responseText = `${cn.clean}

\u2713 ${info}`;
        } else {
          const cn = await cleanNote(zenChat, ZEN_KEY, save.body, "contact details");
          info = await actContact(save.name, cn.clean, cn.summary);
          responseText = `${cn.clean}

\u2713 ${info}`;
        }
      } catch (e) {
        responseText += `

(save failed: ${e.message})`;
      }
    } else if (save) {
      responseText = responseText.replace(/^\[(SAVE-JOURNAL|SAVE-CONTACT:[^\]]+)\]\s*/, "");
    }
    const sources = [];
    const sourceMatches = context.match(/=== (.+?) ===/g);
    if (sourceMatches) {
      for (const m of sourceMatches.slice(0, 5)) {
        sources.push(m.replace(/===/g, "").trim());
      }
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ response: responseText, sources })
    };
  } catch (error) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        response: `Error: ${error.message}`,
        sources: []
      })
    };
  }
};
